namespace Library.Tests;
using TestDateFormat;
public class DataFormatterTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void CorrectTest()
    {
        string TestDate= "10/11/1967";
        string CorrectDate = "1967-11-10" ;
        string actual = DateFormatter.ChangeFormat(TestDate);
        Assert.AreEqual(CorrectDate,actual);
    }
    
    [Test]
    public void NullDate()
    {
        string TestDate= "";
        string CorrectDate = null ;

        Assert.AreEqual(CorrectDate,DateFormatter.ChangeFormat(TestDate));
    }

    [Test]
    public void WrongFormat()
    {
        string TestDate= "11-11-1967";
        string CorrectDate = null ;

        Assert.AreEqual(CorrectDate,DateFormatter.ChangeFormat(TestDate));
    }

    [Test]
    public void WrongLength()
    {
        string TestDate= "11/11/212212";
        string CorrectDate = null ;

        Assert.AreEqual(CorrectDate,DateFormatter.ChangeFormat(TestDate));
    }
}